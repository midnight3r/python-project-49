### Hexlet tests and linter status:
[![Actions Status](https://github.com/midnight3r/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/midnight3r/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/e9b50bf406a258471acd/maintainability)](https://codeclimate.com/github/midnight3r/python-project-49/maintainability)
https://asciinema.org/a/EK3FyArGROoaD5uFYKdxBvbKH
https://asciinema.org/a/DxVrEV5y8VSkRxllxXr9La8ZA
https://asciinema.org/a/xANDQGxboNzyuEx4Xkf7eMMv5
https://asciinema.org/a/M4X4rn82H1pyNBVCJZkniRTJl
https://asciinema.org/a/HHO05mqWexGmHJpjgOQuFEoOu
